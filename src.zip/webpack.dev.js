const { merge } = require("webpack-merge");
const { EnvironmentPlugin } = require("webpack");
const commonConfig = require("./webpack.config.js");

const devConfig = {
    mode: "development",
    devServer: {
        port: 8080,
        open: true,
        hot: true,
        historyApiFallback: true
    },
    plugins: [
        new EnvironmentPlugin({
            API_URL: "http://127.0.0.1:3000/"
        })
    ]
}

module.exports = merge(commonConfig, devConfig);