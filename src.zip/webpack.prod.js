const { merge } = require("webpack-merge");
const { EnvironmentPlugin } = require("webpack");
const commonConfig = require("./webpack.config.js");

const devConfig = {
    mode: "production",
    plugins: [
        new EnvironmentPlugin({
            API_URL: "http://localhost:5001/api"
        })
    ]
}

module.exports = merge(commonConfig, devConfig);