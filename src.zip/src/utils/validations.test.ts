import { isValid } from "./validations.";

describe("va", () => {

    test("null", () => {
        expect(isValid("test")).toBe(true)
    });

});