
export const isValid = (value: any) => {
    return value ? true : false;
}