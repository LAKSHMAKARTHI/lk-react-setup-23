import i18n from "i18next";
import { initReactI18next } from "react-i18next";


//Creating object with the variables of imported translation files
const resources = {
  tn: {
    translation: {
      "showadd": "சேர் காட்டு"
    }
  },
  en: {
    translation: {
      "showadd": "Show Add"
    }
  },
};

//i18N Initialization

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng:"en", //default language
    keySeparator: false,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;