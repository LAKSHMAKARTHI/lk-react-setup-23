import React from "react";
import { ChangeEvent, useState } from "react";
import { userInput } from "../../types/auth";
import useTitle from "../../hooks/useTitle";

const LoginComponent = (props: any) => {
    const [title, setTitle] = useState<string>("project");
    const [user, setUser] = useState<userInput>({
        username: "",
        password: ""   
    });

    const { setNewTitle, setBtnTitle, btnTitle } = useTitle({
        setTitle
    });

    const setValue = (e: ChangeEvent<HTMLInputElement>) => {
        setUser((val) => ({...val, [e.target.name]: e.target.value}));
    }
    
    return (
        <div>
            <input type="text" name="username" onChange={setValue} placeholder="Username" value={user.username} />
            <input type="password" name="password" onChange={setValue} placeholder="Password" value={user.password} />
            <button onClick={() => props.signin(user)}>Sigin</button>
            <button onClick={() => {
                setNewTitle();
                setBtnTitle('clicked')
            }}>{btnTitle} {title}</button>
        </div>
    );
}

export default LoginComponent;