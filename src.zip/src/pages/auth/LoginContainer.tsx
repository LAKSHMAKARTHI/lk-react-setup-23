import { connect } from "react-redux"
import LoginComponent from "./LoginComponent";
import { RootState } from "../../store";
import { updateUser } from "../../reducers/authReducer";
import { userInput } from "../../types/auth";

const mapStateToProps = (state: RootState) => ({
    authReducer: state.authReducer 
});

const mapDispatchToProps = (dispatch: any) => ({
	signin: (e: userInput) => dispatch(updateUser(e))
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent);