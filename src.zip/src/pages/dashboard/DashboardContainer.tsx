import { connect } from "react-redux"
import DashboardComponent from "./DashboardComponent";
import { addProduct, getProducts } from "../../reducers/productReducer";
import { RootState } from "../../store";
import { addProducts } from "../../types/product";

const mapStateToProps = (state: RootState) => ({
    product: state.productReducer.product
});

const mapDispatchToProps = (dispatch: any) => ({
    getProducts: (e: string | number) => dispatch(getProducts(e)),
    addProduct: (e: addProducts) => dispatch(addProduct(e))
});

export default connect(mapStateToProps, mapDispatchToProps)(DashboardComponent);