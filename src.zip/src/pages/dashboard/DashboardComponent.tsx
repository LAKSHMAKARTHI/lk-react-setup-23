import React, { useEffect, useState } from "react";
import { getUserId } from "../../utils/helper";
import ItemComponent from "../../components/ItemComponent";
import AddItemComponent from "../../components/AddItemComponent";
import { useTranslation } from "react-i18next";
import { Button } from "@mui/material";

const DashboardComponent = (props : any) => {
    const { t } = useTranslation();
    const [showModal, setShowModal] = useState<boolean>(false);

    useEffect(() => {
        props.getProducts(getUserId());
    }, [])

    const logout = async () => {
       await localStorage.clear();
       window.location.replace("/");
    }
    
    return (
        <>
        <Button onClick={logout}>Logout</Button>
        <ItemComponent product={props.product} />
        {showModal ? <AddItemComponent onHide={() => setShowModal(false)} onAdd={(e: string) => {
            props.addProduct({uid: parseInt(getUserId() as string), name: e});
        }} /> : <button onClick={() => setShowModal(true)}>{t('showadd')}</button>}
        </>
    );
}

export default DashboardComponent;