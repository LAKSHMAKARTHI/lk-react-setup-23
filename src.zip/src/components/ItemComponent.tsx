import React from "react"

const ItemComponent = (props: any) => {

    return (
        <ol>
        {props.product.map((e: any) => (
            <li>{e.name}</li>
            ))}
        </ol>
    )
}

export default ItemComponent;