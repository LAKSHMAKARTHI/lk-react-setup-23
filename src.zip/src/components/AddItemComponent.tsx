import { Button } from "@mui/material";
import React, { useState } from "react";

interface Props {
    onHide: () => void,
    onAdd: (e: string) => void
}

const AddItemComponent = (props: Props) => {
    const [name, setName] = useState<string>('');

    return (
        <>
            <input type="text" name="pname" placeholder="Product Name" onChange={e => setName(e.target.value)} />
            <Button onClick={() => props.onHide()}>Close</Button>
            <button onClick={() => props.onAdd(name)}>Add</button>
        </>
    )
}

export default AddItemComponent;