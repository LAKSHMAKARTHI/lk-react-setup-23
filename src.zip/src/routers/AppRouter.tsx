import React, { lazy, Suspense, useEffect } from 'react';
import { Route, Routes, useNavigate } from 'react-router-dom';
import { getUserId } from '../utils/helper';

const LoginContainer = lazy(() => import('../pages/auth/LoginContainer'));
const DashboardContainer = lazy(() => import('../pages/dashboard/DashboardContainer'));

const AppRoutes = () => {
  const navigation = useNavigate(); 

  useEffect(() => {
    if (getUserId()) {
      navigation("/dashboard");
    } else {
      navigation("/");
    }
  }, [])

  return (
    <Suspense fallback={<>Loading</>}>
            <Routes>
              {
                (getUserId()) ? <>
                  <Route path={"/dashboard"} element={<DashboardContainer />} />
                </> : <>
                <Route path={"/"} element={<LoginContainer />} />
                </>
              }
              <Route path="*" element={<>404</>} />
            </Routes>
          </Suspense>
  );
};

export default AppRoutes;