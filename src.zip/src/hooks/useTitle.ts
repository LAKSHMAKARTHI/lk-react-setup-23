import { useEffect, useState } from "react";

interface typeProps {
    setTitle: (val: string) => void 
}

const useTitle = (props: typeProps) => {
    const { setTitle } = props;
    const [btnTitle, setBtnTitle] = useState<string>('Click');

    useEffect(() => {
        setTitle("Project Setup...");
    }, []);

    const setNewTitle = () => {
        setTitle("Project Setup")
    }

    return { setNewTitle, setBtnTitle, btnTitle }
}

export default useTitle;