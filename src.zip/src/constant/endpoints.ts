export const PATH = {
    login: '/'
}