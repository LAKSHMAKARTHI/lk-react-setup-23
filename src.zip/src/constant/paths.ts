export const PATH = {
    HOME: '/'
}