export enum AlertTypes {
    FRUIT = 'fruit'
}