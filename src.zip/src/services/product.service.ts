import { addProducts, product } from "../types/product";
import http from "../utils/http";

class ProductService {

    getProducts (uid : string | number) {
        return http.get<product[]>(`products?uid=${uid}`);
    }

    addProducts (product : addProducts) {
        return http.post<any>("products", product);
    }
}

export default new ProductService();