import authService from './auth.service';
import { userInput } from '../types/auth';
import MockAdapter from 'axios-mock-adapter'
import http from '../utils/http';

describe.skip("Auth Service", () => {
    var mock = new MockAdapter(http);

    beforeEach(() => {
        mock.reset();
    });

    test('Success Login', async () => {
        
        const user : userInput = {
            username: "karthi",
            password: "123"
        }

        mock.onGet(`users?username=${user.username}&password=${user.password}`).reply(200, [{
            "id": 1,
            "username": "karthi",
            "password": "123"
          }]);
        
        try {
            const res = await authService.login(user);
            expect(res).toBeDefined();
        } catch (err) {
            //expect(err).toBeDefined();
        }
        
      });
});
