import { user, userInput } from "../types/auth";
import http from "../utils/http";

class AuthService {

    login (user : userInput) {
        return http.get<user>(`users?username=${user.username}&password=${user.password}`);
    }
}

export default new AuthService();