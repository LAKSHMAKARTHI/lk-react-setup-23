import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import { ProductState, addProducts, product } from '../types/product'
import productService from '../services/product.service'
  
export const addProduct = createAsyncThunk<
  any,
  addProducts
>('product/update', async (product) => {
  const response = await productService.addProducts(product);
  return (await response.data)
})

export const getProducts = createAsyncThunk<
  product[],
  string | number
>('product/get', async (user) => {
  const response = await productService.getProducts(user);
  return (await response.data)
})

const initialState: ProductState = {
  product: [],
  error: "",
  isLoading: false
}

export const productSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    //get Product
    builder.addCase(addProduct.pending, (state) => {
        state.isLoading = true
    })
    builder.addCase(addProduct.fulfilled, (state) => {
        state.isLoading = false;
    })
    builder.addCase(addProduct.rejected, (state) => {
        state.isLoading = false
        state.error = "failed"
    })
    //add Product
    builder.addCase(getProducts.pending, (state) => {
      state.isLoading = true
    })
    builder.addCase(getProducts.fulfilled, (state, action: PayloadAction<any>) => {
      localStorage.setItem("token", action.payload[0].id.toString());
      state.isLoading = false;
      state.product = action.payload
    })
    builder.addCase(getProducts.rejected, (state) => {
        state.isLoading = false
        state.error = "failed"
    })
},
})

export const { } = productSlice.actions

export default productSlice.reducer