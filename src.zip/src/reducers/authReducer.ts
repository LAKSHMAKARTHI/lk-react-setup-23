
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'
import { AuthState, user, userInput } from '../types/auth'
import authService from '../services/auth.service'

interface MyKnownError {
  errorMessage: string
}
  
export const updateUser = createAsyncThunk<
  user,
  userInput,
  {
    extra: {
      jwt: string
    }
    rejectValue: MyKnownError
  }
>('users/update', async (user) => {
  const response = await authService.login(user);
  return (await response.data)
})

const initialState: AuthState = {
  userId: "",
  error: "",
  isLoading: false
}

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    incrementByAmount: (state, action: PayloadAction<number>) => {
      state.error += action.payload
    },
  },
  extraReducers: (builder) => {
    builder.addCase(updateUser.pending, (state) => {
      state.isLoading = true
  })
    builder.addCase(updateUser.fulfilled, (state, action: PayloadAction<any>) => {
      localStorage.setItem("token", action.payload[0]?.id?.toString());
      window.location.replace("/dashboard");
      state.isLoading = false;
      state.userId = action.payload[0]?.id?.toString()
    })
    builder.addCase(updateUser.rejected, (state) => {
        state.isLoading = false
        state.error = "failed"
    })
},
})

export const { incrementByAmount } = authSlice.actions

export default authSlice.reducer