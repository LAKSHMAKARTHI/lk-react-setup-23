
export interface userInput {
    username: string,
    password: string
}

export interface user extends userInput {
    id: number
}

export interface AuthState {
    userId: string,
    error: string,
    isLoading: boolean
}
