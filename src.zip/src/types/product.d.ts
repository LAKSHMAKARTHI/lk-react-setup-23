
export interface product {
    id: number,
    uid: number,
    name: string
}

export interface addProducts {
    id: number,
    uid: number,
    name: string
}

export interface ProductState {
    product: product[],
    error: string,
    isLoading: boolean
}